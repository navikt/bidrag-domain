@file:Suppress("unused")

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import jakarta.persistence.AttributeConverter
import java.sql.Date
import java.time.LocalDate
import no.nav.bidrag.domain.felles.Verdiobjekt
import org.springframework.core.convert.converter.Converter

class ${NAME}(override val verdi: LocalDate) : Verdiobjekt<LocalDate>()

class ${NAME}ReadingConverter : Converter<Date, ${NAME}> {
    override fun convert(source: Date) = ${NAME}(source.toLocalDate())
}

class ${NAME}WritingConverter : Converter<${NAME}, Date> {
    override fun convert(source: ${NAME}) = Date.valueOf(source.verdi)
}

class ${NAME}Converter : AttributeConverter<${NAME}, LocalDate> {
    override fun convertToEntityAttribute(source: LocalDate?) = source?.let { ${NAME}(source) }
    override fun convertToDatabaseColumn(source: ${NAME}?) = source?.verdi
}
