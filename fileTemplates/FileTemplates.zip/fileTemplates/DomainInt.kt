@file:Suppress("unused")

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import jakarta.persistence.AttributeConverter
import no.nav.bidrag.domain.felles.Verdiobjekt
import org.springframework.core.convert.converter.Converter

class ${NAME}(override val verdi: Int) : Verdiobjekt<Int>()

class ${NAME}ReadingConverter : Converter<Int, ${NAME}> {
    override fun convert(source: Int) = ${NAME}(source)
}

class ${NAME}WritingConverter : Converter<${NAME}, Int> {
    override fun convert(source: ${NAME}) = source.verdi
}

class ${NAME}Converter : AttributeConverter<${NAME}, Int> {
    override fun convertToEntityAttribute(source: Int?) = source?.let { ${NAME}(source) }
    override fun convertToDatabaseColumn(source: ${NAME}?) = source?.verdi
}
