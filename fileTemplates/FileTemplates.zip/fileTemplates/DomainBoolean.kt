@file:Suppress("unused")

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import jakarta.persistence.AttributeConverter
import no.nav.bidrag.domain.felles.Verdiobjekt
import no.nav.bidrag.domain.felles.StringToBooleanConverter
import org.springframework.core.convert.converter.Converter

class ${NAME}(override val verdi: Boolean) : Verdiobjekt<Boolean>()

class ${NAME}ReadingConverter : Converter<String, ${NAME}> {
    override fun convert(source: String) = ${NAME}(StringToBooleanConverter().convert(source))
}

class ${NAME}WritingConverter : Converter<${NAME}, Boolean> {
    override fun convert(source: ${NAME}) = source.verdi
}

class ${NAME}Converter : AttributeConverter<${NAME}, Boolean> {
    override fun convertToEntityAttribute(source: Boolean?) = source?.let { ${NAME}(source) }
    override fun convertToDatabaseColumn(source: ${NAME}?) = source?.verdi
}
