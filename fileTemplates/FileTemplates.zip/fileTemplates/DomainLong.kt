@file:Suppress("unused")

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import jakarta.persistence.AttributeConverter
import no.nav.bidrag.domain.felles.Verdiobjekt
import org.springframework.core.convert.converter.Converter

data class ${NAME}(override val verdi: Long) : Verdiobjekt<Long>

class ${NAME}ReadingConverter : Converter<Long, ${NAME}> {
    override fun convert(source: Long) = ${NAME}(source)
}

class ${NAME}WritingConverter : Converter<${NAME}, Long> {
    override fun convert(source: ${NAME}) = source.verdi
}

class ${NAME}Converter : AttributeConverter<${NAME}, Long> {
    override fun convertToEntityAttribute(source: Long?) = source?.let { ${NAME}(source) }
    override fun convertToDatabaseColumn(source: ${NAME}?) = source?.verdi
}
